package CompanyTest;

import java.util.Scanner;

public class AcceptEmail {
	public static void main(String[] args) {
		 
		Scanner sc=new Scanner(System.in);
		final String x="student01@gmail.com";
		System.out.println("Enter a String");
		String a=sc.next();
		
		for(int i=0;i<a.length();i++)
		{
			if(a.equals(x))
			{
				System.out.println("Valid Email Id");
				break;
			}
			else
			{
				System.out.println("Invalid Email Id");
				break;
			}
		}
	}

}
